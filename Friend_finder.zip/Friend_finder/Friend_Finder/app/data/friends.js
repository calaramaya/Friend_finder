var friends = [
    {
        name: "Liverpool",
        photo: "https://cdn.images.express.co.uk/img/dynamic/galleries/x701/137182.jpg",
        scores: []
    },
    {

        "name": "Stevie G",
        "photo": "http://cdn.empireofthekop.com/wp-content/uploads/2015/05/Steven-Gerrard5.jpg",
        "scores": [
            5,
            1,
            4,
            4,
            5,
            1,
            2,
            5,
            4,
            1
        ]
    },
    {
        "name": "Jurgen",
        "photo": "https://cdn.images.dailystar.co.uk/dynamic/58/photos/354000/620x/Liverpool-boss-Jurgen-Klopp-635202.jpg",
        "scores": [
            5,
            1,
            4,
            4,
            5,
            1,
            2,
            5,
            4,
            1
        ]
    },
    {
        "name": "Rafa",
        "photo": "https://cdn.images.dailystar.co.uk/dynamic/58/photos/521000/620x/Rafa-Benitez-696383.jpg",
        "scores": [
            3,
            1,
            4,
            4,
            5,
            1,
            2,
            5,
            4,
            1
        ]
    },
    {
        "name": "John",
        "photo": "https://cdn.images.express.co.uk/img/dynamic/67/590x/henry-421152.jpg",
        "scores": [
            4,
            1,
            4,
            3,
            2,
            6,
            4,
            5,
            4,
            5
        ]
    },
    {
        "name": "Ian",
        "photo": "https://5times.co.uk/wp-content/uploads/2017/08/ian-rush-crown-1.jpg",
        "scores": [
            5,
            1,
            4,
            3,
            2,
            5,
            3,
            4,
            5,
            4
        ]
    },
    {
        "name": "Robbie",
        "photo": "https://img.maximummedia.ie/sportsjoe_ie/eyJkYXRhIjoie1widXJsXCI6XCJodHRwOlxcXC9cXFwvbWVkaWEtc3BvcnRzam9lLm1heGltdW1tZWRpYS5pZS5zMy5hbWF6b25hd3MuY29tXFxcL3dwLWNvbnRlbnRcXFwvdXBsb2Fkc1xcXC8yMDE2XFxcLzEyXFxcLzA1MjMxMzM5XFxcL0dldHR5SW1hZ2VzLTk1MjI2NDEuanBnXCIsXCJ3aWR0aFwiOjY0MCxcImhlaWdodFwiOjM2MCxcImRlZmF1bHRcIjpcImh0dHBzOlxcXC9cXFwvd3d3LnNwb3J0c2pvZS5pZVxcXC9hc3NldHNcXFwvaW1hZ2VzXFxcL3Nwb3J0c2pvZVxcXC9uby1pbWFnZS5wbmc_dj01XCJ9IiwiaGFzaCI6IjA2MDQ4NjJlN2Q3NzRmZjc1NDMzZGMxZTIwNjQ1ZDVkMzQ0MzRmNDMifQ==/gettyimages-9522641.jpg",
        "scores": [
            5,
            1,
            4,
            3,
            2,
            5,
            4,
            5,
            5,
            5
        ]
    },
    {
        "name": "Kenny",
        "photo": "https://cdn.images.express.co.uk/img/dynamic/67/590x/Kenny-Dalglish-will-be-the-first-Liverpool-player-to-have-a-stand-named-after-him-799814.jpg",
        "scores": [
            5,
            1,
            4,
            3,
            2,
            5,
            4,
            4,
            4,
            3
        ]
    },
    {
        "name": "Jamie",
        "photo": "https://i2.wp.com/short-biography.com/wp-content/uploads/jamie-carragher/Jamie-Carragher.jpg?w=2364&ssl=1",
        "scores": [
            5,
            1,
            4,
            3,
            2,
            4,
            3,
            4,
            3,
            4
        ]
    },
    {
        "name": "Lucas",
        "photo": "http://e0.365dm.com/17/07/16-9/20/skysports-lucas-liverpool-sky-sports_4004924.jpg?20170718182435",
        "scores": [
            5,
            1,
            4,
            3,
            2,
            5,
            5,
            2,
            4,
            3
        ]
    },
    {
        "name": "Lebron",
        "photo": "https://mk0slamonlinensgt39k.kinstacdn.com/wp-content/uploads/2012/08/james.jpg",
        "scores": [
            5,
            1,
            4,
            3,
            2,
            5,
            5,
            4,
            4,
            5
        ]
    }

];


module.exports = friends;
